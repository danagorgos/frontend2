// AuthContext.js

import React, { createContext, useState } from 'react';

const EditContext = createContext();

const EditShopProvider = ({ children }) => {
  const [editState, setEditState] = useState({});


  return (
    <EditContext.Provider value={{ editState, setEditState }}>
      {children}
    </EditContext.Provider>
  );
};

export { EditContext, EditShopProvider };
