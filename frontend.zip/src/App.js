import './App.css';
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import { useLocation } from "react-router-dom";

import Sidebar from './components/sidebar/sidebar';
import SignUpComponent from './pages/sign-up/signup';
import SignInComponent from './pages/sign-in/signin';
import ShoppingListComponent from './components/shopping-list/shopping-list';
import CreateItem from './pages/create-item/create-item';
import CreateShoppingList from './pages/create-shopping-list/create-shopping-list';
import ShoppingDetail from './pages/shopping-detail/shopping-detail';
function App() {
  const location = useLocation();
  return (
    <>
      <Routes>
        <Route path="/signup" element={<SignUpComponent />} />
        <Route path="/signin" element={<SignInComponent />} />
        <Route path="/shoppingList" element={<ShoppingListComponent />} />
        <Route path="/create-item" element={<CreateItem />} />
        <Route path="/create-shopping-list" element={<CreateShoppingList />} />
        <Route path="/shopping-list-detail/:id" element={<ShoppingDetail />} />
        <Route path="/" element={<Navigate to="/shoppingList" />} />

      </Routes>
      <div className="col-20">
        <Sidebar />
      </div>
    </>

  );
}

export default App;
