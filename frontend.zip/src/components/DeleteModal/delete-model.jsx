import React from 'react'
import {
    Button,
    Checkbox,
    FormLabel,
    Paper,
    Select,
    TextField,
    Box,
    Modal
} from "@mui/material";
const DeleteModal = ({ isOpen, onClose, onDelete }) => {
    return (
        <Modal
            open={isOpen}
            onClose={onClose}
            aria-labelledby="delete-confirmation-modal"
        >
            <Box
                sx={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    width: 300,
                    bgcolor: "background.paper",
                    boxShadow: 24,
                    p: 2,
                    borderRadius: 4,
                    textAlign: "center",
                }}
            >
                <h2>Are you sure you want to delete this item?</h2>
                <Button
                    variant="contained"
                    color="error"
                    onClick={() => {
                        onDelete();
                        onClose();
                    }}
                >
                    Yes, Delete
                </Button>
                <Button variant="contained" onClick={onClose}>
                    No, Cancel
                </Button>
            </Box>
        </Modal>
    );
}

export default DeleteModal