import React from 'react'
import {
    Button,
    Checkbox,
    FormLabel,
    Paper,
    Select,
    TextField,
    FormControlLabel,
    Modal
} from "@mui/material";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
const CreateShoppingModal = ({ isOpen, onClose, formData,
    handleCreateShoppingList, handleInputChange,handleMemberSelect,handleItemSelect,users,items
 }) => {
    return (
        <Modal open={isOpen} onClose={onClose}>
            <div>
                <h2 className="heading">Create Shopping List</h2>
                <div className="main-div">

                    <div className="form-div">
                        <TextField label="Name" name="name" value={formData.name} onChange={handleInputChange} />
                        <TextField label="Owner" name="owner" value={formData.owner} onChange={handleInputChange} />
                        <FormControlLabel
                            control={
                                <Checkbox
                                    name="isArchived"
                                    checked={formData.isArchived}
                                    onChange={handleInputChange} // Make sure your handleInputChange function handles the Checkbox change
                                />
                            }
                            label="Is Archived"
                        />                        <FormControl fullWidth>
                            <InputLabel id="demo-simple-select-label">Members</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                // value={age}
                                label="Members"
                                onChange={handleMemberSelect}
                            >
                                {users.map((value) => (
                                    <MenuItem key={value} value={value}>
                                        {value.userName}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <FormControl fullWidth>
                            <InputLabel id="demo-simple-select-label">Items</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                // value={age}
                                label="Items"
                                onChange={handleItemSelect}
                            >
                                {items.map((value) => (
                                    <MenuItem key={value} value={value}>
                                        {value.productTitle}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <Button variant="contained" type="submit" onClick={handleCreateShoppingList}>
                            Submit
                        </Button>
                        <Button variant="contained" type="submit" onClick={onClose}>
                            Close
                        </Button>
                    </div>
                </div>
            </div>
        </Modal>
    );
}

export default CreateShoppingModal