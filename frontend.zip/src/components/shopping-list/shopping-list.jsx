import React, { useState, useEffect, useContext } from 'react'
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import axios from 'axios';
import "./shopping-list.css";
import { useNavigate } from 'react-router-dom';
const ShoppingListComponent = () => {
  const [response, setResponse] = useState(null);
  const [shoppingList, setShoppingList] = useState([]);
  const navigate = useNavigate();


  const getShoppingList = async () => {
    const apiUrl = `http://localhost:5001/api/shopping/list`;
    try {
      const response = await axios.get(apiUrl);
      setShoppingList(response.data)
      setResponse(response.data);
    } catch (error) {
      console.error('Error:', error);
    }
  }

  useEffect(() => {
    getShoppingList();
  }, []);

  const navigateToDetail = (shop) => {
    navigate(`/shopping-list-detail/${shop._id}`)
  }

  return (
    <div className="card-div">
      {shoppingList.map((shop, index) => (
        <div className="card-container" key={index}>
          <Card sx={{ minWidth: 275 }}>
            <CardContent>
              <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                {shop.name}
              </Typography>
              <Typography variant="body2">
                <b>Members:</b> {shop.members[0]?.userName}
                <br />
                <b>Items:</b> {shop.items[0]?.productTitle}
              </Typography>
            </CardContent>
            <CardActions>
              <Button size="small" onClick={() => navigateToDetail(shop)}>Learn More</Button>
            </CardActions>
          </Card>
        </div>
      ))}
    </div>
  )
}

export default ShoppingListComponent