import React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Divider from '@mui/material/Divider';
import { useNavigate } from 'react-router-dom';
import './sidebar.css';

const Sidebar = () => {
  const navigate = useNavigate();

  const navigateToCreateProduct = () => {
    navigate('/create-item');
  };

  const navigateToShoppingList = () => {
    navigate('/shoppingList');
  };

  const navigateToCreateShopping = () => {
    navigate('/create-shopping-list');
  };

  return (
    <Drawer className='side-drawer' variant="permanent">
      <List>
        <ListItem>
          <ListItemButton onClick={navigateToCreateShopping}>
            <ListItemText primary="Create Shopping List" />
          </ListItemButton>
        </ListItem>
        <ListItem>
          <ListItemButton onClick={navigateToShoppingList}>
            <ListItemText primary="Get Shopping List" />
          </ListItemButton>
        </ListItem>
        <ListItem>
          <ListItemButton onClick={navigateToCreateProduct}>
            <ListItemText primary="Create Item" />
          </ListItemButton>
        </ListItem>
      </List>
      <Divider />
    </Drawer>
  );
};

export default Sidebar;
