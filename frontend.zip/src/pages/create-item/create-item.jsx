import React, { useState,useRef,useEffect} from 'react';
import './create-item.css';
import {
    Button,
    TextField,
} from "@mui/material";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const CreateItem = () => {
    const [formData, setFormData] = useState({
        productTitle: '',
        productDescription: ''
    });
    const [response, setResponse] = useState(null);
    const navigate = useNavigate();

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleCreateProduct = async (e) => {
        e.preventDefault(); // Prevent the form from submitting and causing a page refresh
        const apiUrl = 'http://localhost:5001/api/create-product';
        try {
            const response = await axios.post(apiUrl, formData);
            console.log(response.data);
            setResponse(response.data);
            navigate('/create-shopping-list')
        } catch (error) {
            console.error('Error:', error);
        }
        setFormData('');

    }

    return (
        <div>
            <h2 className="heading">Create Item</h2>
            <div className="main-div">
                <div className="form-div">
                    <form onSubmit={handleCreateProduct}>
                        <TextField
                            label="Name"
                            // variant="outlined"
                            name="productTitle"
                            value={formData.productTitle}
                            onChange={handleInputChange}
                        />
                        <TextField
                            label="Description" 
                            variant="outlined"
                            name="productDescription"
                            value={formData.productDescription}
                            onChange={handleInputChange}
                        />
                        <Button
                            variant="contained"
                            color="primary"
                            type="submit"
                        >
                            Submit
                        </Button>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default CreateItem;
