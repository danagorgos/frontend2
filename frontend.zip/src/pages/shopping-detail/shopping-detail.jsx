import React, { useState, useEffect, useContext } from 'react'
import { useParams } from 'react-router-dom';
import axios from 'axios';
import {
    Button,
    Checkbox,
    FormLabel,
    Paper,
    Select,
    TextField,
    Box,
    Modal
} from "@mui/material";
import { useNavigate } from 'react-router-dom';
import "./shopping-detail.css"
import { EditContext } from '../../context/edit-shopping.context';
import DeleteModal from '../../components/DeleteModal/delete-model';


const ShoppingDetail = () => {
    const [detail, setDetail] = useState({})
    const { id } = useParams();
    const navigate = useNavigate();
    const { setEditState } = useContext(EditContext);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);



    const getShoppingDetail = async () => {
        const apiUrl = `http://localhost:5001/api/shopping/${id}`;
        try {
            const response = await axios.get(apiUrl);
            setDetail(response.data)
        } catch (error) {
            console.error('Error:', error);
        }
    }

    const deleteShoppingList = async (id) => {
        const apiUrl = `http://localhost:5001/api/delete/shopping/${id}`;
        try {
            const response = await axios.delete(apiUrl);
            navigate(`/shoppingList`)
        } catch (error) {
            console.error('Error:', error);
        }
    }

    const editShoppingList = (detail) => {
        setEditState(detail);
        navigate(`/create-shopping-list`)


    }

    useEffect(() => {
        getShoppingDetail();
    }, []);

    return (
        <div className="detail-div">
            <div>
                <h1>{detail.name}</h1>
                <Button variant="contained" type="submit" onClick={() => setIsDeleteModalOpen(true)}>
                    Delete
                </Button>
            </div>
            <DeleteModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onDelete={() => deleteShoppingList(detail._id)}
            />
        </div>
    )
}

export default ShoppingDetail