import React, { useState, useEffect, useContext } from 'react'
import {
    Button,
    Checkbox,
    FormLabel,
    Paper,
    Select,
    TextField,
    FormControlLabel
} from "@mui/material";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import axios from 'axios';
import './create-shopping-list.css';
import { useNavigate } from 'react-router-dom';
import { EditContext } from '../../context/edit-shopping.context';

const CreateShoppingList = () => {
    const [formData, setFormData] = useState({
        name: '',
        isArchived: false,
        owner: '',
        members: [],
        items: [],
    });
    const [response, setResponse] = useState(null);
    const [users, setUsers] = useState([]);
    const [items, setItem] = useState([]);
    const navigate = useNavigate();
    const { editState } = useContext(EditContext);
    // const member = editState.members[0];
    // const [selectedMember, setSelectedMember] = useState(member);



    const handleInputChange = (e) => {
        const { name, value, checked, type } = e.target;
        if (type === 'checkbox') {
            setFormData({ ...formData, [name]: checked });
        } else {
            setFormData({ ...formData, [name]: value });
        }
    };
    const handleCreateShoppingList = async () => {
        if (editState._id) {
            const apiUrl = `http://localhost:5000/api/update/shopping/${editState._id}`;
            try {
                const response = await axios.put(apiUrl, formData);
                setResponse(response.data);
                navigate('/shoppingList')
            } catch (error) {
                console.error('Error:', error);
            }
            setFormData('');
        }
        else {
            const apiUrl = 'http://localhost:5000/api/create/shopping';
            try {
                const response = await axios.post(apiUrl, formData);
                setResponse(response.data);
                navigate('/shoppingList')
            } catch (error) {
                console.error('Error:', error);
            }
            setFormData('');
        }

    }

    const getUserList = async () => {
        const apiUrl = 'http://localhost:5001/api/users';
        try {
            const response = await axios.get(apiUrl); // Use axios.get for a GET request
            setUsers(response.data.users)
            setResponse(response.data);
        } catch (error) {
            console.error('Error:', error);

        }
    }
    const getItemList = async () => {
        const apiUrl = 'http://localhost:5001/api/products';
        try {
            const response = await axios.get(apiUrl);
            const responseData = response.data;
            setItem(responseData);
            setResponse(responseData);
        } catch (error) {
            console.error('Error:', error);
        }
    }

    useEffect(() => {
        getUserList();
        getItemList();
    }, []);

    const handleMemberSelect = (event) => {
        const selectedMembers = event.target.value;
        setFormData({ ...formData, members: selectedMembers }); // Spread existing formData
    };

    const handleItemSelect = (event) => {
        const selectedItem = event.target.value;
        setFormData({ ...formData, items: selectedItem }); // Spread existing formData
    };


    return (
        <div>
            <h2 className="heading">Create Shopping List</h2>
            <div className="main-div">

                <div className="form-div">
                    <TextField label="Name" name="name" value={formData.name} onChange={handleInputChange} />
                    <TextField label="Owner" name="owner" value={formData.owner} onChange={handleInputChange} />
                    <FormControlLabel
                        control={
                            <Checkbox
                                name="isArchived"
                                checked={formData.isArchived}
                                onChange={handleInputChange} // Make sure your handleInputChange function handles the Checkbox change
                            />
                        }
                        label="Is Archived"
                    />                        <FormControl fullWidth>
                        <InputLabel id="demo-simple-select-label">Members</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            // value={age}
                            label="Members"
                            onChange={handleMemberSelect}
                        >
                            {users.map((value) => (
                                <MenuItem key={value} value={value}>
                                    {value.userName}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <FormControl fullWidth>
                        <InputLabel id="demo-simple-select-label">Items</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            // value={age}
                            label="Items"
                            onChange={handleItemSelect}
                        >
                            {items.map((value) => (
                                <MenuItem key={value} value={value}>
                                    {value.productTitle}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                    <Button variant="contained" type="submit" onClick={handleCreateShoppingList}>
                        Submit
                    </Button>
                </div>
            </div>
        </div>
    )
}
export default CreateShoppingList