import React, { useState, useEffect, useContext } from 'react'
import {
    Button,
    Checkbox,
    FormLabel,
    Paper,
    Select,
    TextField,
    FormControlLabel
} from "@mui/material";
import './create-shopping-list.css';
import { useNavigate } from 'react-router-dom';
import { EditContext } from '../../context/edit-shopping.context';
import CreateShoppingModal from '../../components/CreateShoppingModal/create-shopping-modal';
import axios from 'axios';

const CreateShoppingList = () => {
    const [formData, setFormData] = useState({
        name: '',
        isArchived: false,
        owner: '',
        members: [],
        items: [],
    });
    const [response, setResponse] = useState(null);
    const [users, setUsers] = useState([]);
    const [items, setItem] = useState([]);
    const navigate = useNavigate();
    const { editState } = useContext(EditContext);
    const [isModalOpen, setIsModalOpen] = useState(false);



    const handleInputChange = (e) => {
        const { name, value, checked, type } = e.target;
        if (type === 'checkbox') {
            setFormData({ ...formData, [name]: checked });
        } else {
            setFormData({ ...formData, [name]: value });
        }
    };

    const handleCreateShoppingList = async () => {
        if (editState._id) {
            const apiUrl = `http://localhost:5001/api/update/shopping/${editState._id}`;
            try {
                const response = await axios.put(apiUrl, formData);
                setResponse(response.data);
                navigate('/shoppingList')
            } catch (error) {
                console.error('Error:', error);
            }
            setFormData('');
        }
        else {
            const apiUrl = 'http://localhost:5001/api/create/shopping';
            try {
                const response = await axios.post(apiUrl, formData);
                setResponse(response.data);
                navigate('/shoppingList')
            } catch (error) {
                console.error('Error:', error);
            }
            setFormData('');
        }
    }

    const getUserList = async () => {
        const apiUrl = 'http://localhost:5001/api/users';
        try {
            const response = await axios.get(apiUrl); // Use axios.get for a GET request
            setUsers(response.data.users)
            setResponse(response.data);
        } catch (error) {
            console.error('Error:', error);

        }
    }
    const getItemList = async () => {
        const apiUrl = 'http://localhost:5001/api/products';
        try {
            const response = await axios.get(apiUrl);
            const responseData = response.data;
            setItem(responseData);
            setResponse(responseData);
        } catch (error) {
            console.error('Error:', error);
        }
    }

    useEffect(() => {
        getUserList();
        getItemList();
    }, []);

    const handleMemberSelect = (event) => {
        const selectedMembers = event.target.value;
        setFormData({ ...formData, members: selectedMembers }); // Spread existing formData
    };

    const handleItemSelect = (event) => {
        const selectedItem = event.target.value;
        setFormData({ ...formData, items: selectedItem }); // Spread existing formData
    };

    const openModal = () => {
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };



    return (
        // <CreateShoppingModal />
        <div>
            <h2 className="heading">Create Shopping List</h2>
            <div>
                <div className='button-div'>
                    <Button className="create-button" variant="contained" type="button" onClick={openModal}>
                        Create Shopping
                    </Button>
                </div>
            </div>
            <CreateShoppingModal
                isOpen={isModalOpen}
                onClose={closeModal}
                formData={formData}
                handleInputChange={handleInputChange}
                handleMemberSelect={handleMemberSelect}
                handleItemSelect={handleItemSelect}
                users={users}
                items={items}
                handleCreateShoppingList={handleCreateShoppingList}
            />
        </div>

    )
}
export default CreateShoppingList