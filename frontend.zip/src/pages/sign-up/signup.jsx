import React, { useState } from 'react';
import './form.css'
import {
    Button,
    Checkbox,
    FormControl,
    FormLabel,
    Paper,
    Select,
    TextField,
} from "@mui/material";
import axios from 'axios';
const SignUpComponent = () => {
    const [formData, setFormData] = useState({
        userName: '',
        email: '',
        password: '',
    });
    const [response, setResponse] = useState(null);


    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSignUp = async () => {
        const apiUrl = 'http://localhost:5000/api/register';
        try {
            const response = await axios.post(apiUrl, formData);
            console.log(response.data);
            setResponse(response.data);
        } catch (error) {
            console.error('Error:', error);
        }
        setFormData('');

    }


    return (
        <>
            <h2 className="heading">Sign Up</h2>
            <div className="main-div">
                <div className='form-div'>
                    <TextField label="UserName" name="userName"
                        value={formData.userName} onChange={handleInputChange} />
                    <TextField label="Email" name="email"
                        value={formData.email} onChange={handleInputChange} />
                    <TextField label="Password" name="password"
                        value={formData.password} onChange={handleInputChange} />
                    <Button variant="contained" type="submit" onClick={handleSignUp}>Submit</Button>
                </div>
            </div>
        </>



    )
}

export default SignUpComponent