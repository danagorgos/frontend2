import React, { useState } from 'react';
import './form.css'
import {
    Button,
    Checkbox,
    FormControl,
    FormLabel,
    Paper,
    Select,
    TextField,
} from "@mui/material";
import axios from 'axios';
import validator from 'validator';

const SignUpComponent = () => {
    const [formData, setFormData] = useState({
        userName: '',
        email: '',
        password: '',
    });
    const [response, setResponse] = useState(null);
    const [errors, setErrors] = useState({});


    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setErrors({
            ...errors,
            [name]: '',
        });
        setFormData({ ...formData, [name]: value });
    };

    const handleSignUp = async () => {
        // e.preventDefault();

        // Validation for user name
        if (!validator.isLength(formData.userName, { min: 4, max: 30 })) {
            setErrors({
                ...errors,
                userName: "Name should have 4 to 30 characters",
            });
            return;
        }

        // Validation for email
        if (!validator.isEmail(formData.email)) {
            setErrors({
                ...errors,
                email: "Please Enter a valid Email",
            });
            return;
        }

        // Validation for password
        if (!validator.isLength(formData.password, { min: 8 })) {
            setErrors({
                ...errors,
                password: "Password should be at least 8 characters",
            });
            return;
        }
        const apiUrl = 'http://localhost:5001/api/register';
        try {
            const response = await axios.post(apiUrl, formData);
            console.log(response.data);
            setResponse(response.data);
        } catch (error) {
            console.error('Error:', error);
        }
        setFormData('');
    }
    return (
        <>
            <h2 className="heading">Sign Up</h2>
            <div className="main-div">
                <div className='form-div'>
                    <TextField label="UserName" name="userName"
                        value={formData.userName} onChange={handleInputChange} />
                    {errors.userName && <div className="error" style={{ color: "red" }}>{errors.userName}</div>}

                    <TextField label="Email" name="email"
                        value={formData.email} onChange={handleInputChange} required />
                    {errors.email && <div className="error" style={{ color: "red" }}>{errors.email}</div>}

                    <TextField label="Password" name="password"
                        value={formData.password} onChange={handleInputChange} />
                    <Button variant="contained" type="submit" onClick={handleSignUp}>Submit</Button>
                </div>
            </div>
        </>



    )
}

export default SignUpComponent